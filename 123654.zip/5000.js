var toto = new ActiveXObject("WScript.Shell")
toto.run("calc.exe");